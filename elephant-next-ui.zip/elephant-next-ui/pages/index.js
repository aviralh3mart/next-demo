import InnerComponent from '../components/Home'

export default function Home() {
  return (
    <InnerComponent />
  )
}
