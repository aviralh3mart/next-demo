import { Fragment } from 'react';

export default function About() {
    return (
        <Fragment>Hello</Fragment>
    )
}
